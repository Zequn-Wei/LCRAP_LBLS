All the instances are in the format of：
The total number of task nodes.
The total number of command nodes.
Resource demand of task nodes.
Resource capacity of command nodes.
Maximum communication coverage distance of command nodes.
Distance between task nodes and command nodes.
Time taken by command nodes to complete tasks.
Maximum time limit for task nodes to be completed.